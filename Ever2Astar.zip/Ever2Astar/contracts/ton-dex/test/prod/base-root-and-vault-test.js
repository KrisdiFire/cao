const tests = require(process.cwd() + '/test/01-base-root-and-vault-test');
