npx locklift test --disable-build  --config locklift.config.js --network local --tests test/70-credit-eth-ton.js --token_id='tst' --amount=1000 --token_amount='0' --ton_amount='3' --swap_type='0'
npx locklift test --disable-build  --config locklift.config.js --network local --tests test/80-hidden-bridge.js --token_id='tst' --amount=1000 --token_amount='0' --ton_amount='3' --swap_type='0'

#npx locklift test --disable-build  --config locklift.config.js --disable-build --network local --tests test/70-credit-eth-ton.js --token_id='tst' --amount=1000 --token_amount=0 --ton_amount=1 --swap_type=1
#npx locklift test --disable-build  --config locklift.config.js --disable-build  --network local --tests test/70-credit-eth-ton.js --token_id='wever' --amount=20 --token_amount=10 --ton_amount=4
#npx locklift test --disable-build  --config locklift.config.js --disable-build --network local --tests test/70-credit-eth-ton.js --token_id='tst' --amount=1000 --token_amount=0 --ton_amount=1 --swap_type=1
#npx locklift test --disable-build  --config locklift.config.js --network local --tests test/70-credit-eth-ton.js --token_id='tst' --amount=1000 --token_amount=0 --ton_amount=1 --swap_type=0
