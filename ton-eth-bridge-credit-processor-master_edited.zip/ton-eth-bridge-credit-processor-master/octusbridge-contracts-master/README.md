# Welcome to the Everscale bridge

This document is a starting point about the Everscale bridge between EVM networks and FreeTON.

## Getting started

* [Litepaper V2](docs/litepaper.md)
* [Artifacts V1](docs/artifacts.md)
* [Strategies](docs/strategies.md)
